import { DataBase } from "../../../database"

// export const existsCompany = async (id: number | any, { req }: { req: Request | any }): Promise<void> => {
//     const company = await DataBase.instance.company.findOne({
//       where: { id },
//     })
//     if (!company) throw new Error(`Empresa no existe`)
//   }
  