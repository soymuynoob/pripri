declare namespace Express {
  export interface Request {
    ext?: string
    mimetype?: string
  }
}
